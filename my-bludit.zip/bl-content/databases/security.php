<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{"minutesBlocked":5,"numberFailuresAllowed":10,"blackList":[{"lastFailure":1703420728,"numberFailures":2}]}