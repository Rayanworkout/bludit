<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{"googleFonts":true,"darkMode":true,"dateFormat":"relative","showTags":true,"position":1}